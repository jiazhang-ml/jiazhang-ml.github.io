# PSAT
Towards Cross-Brain Computer Interface: A Prototype-Supervised Adversarial Transfer Learning Approach with Multiple Sources
