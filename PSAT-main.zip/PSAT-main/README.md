# PSAT
J. Zhang, J. Fang, S. Liu, D. Liu, H. Wu, J. Long. Toward cross-brain-computer interface: A prototype-supervised adversarial transfer learning approach with multiple sources. IEEE Transactions on Instrumentation and Measurement, 2024, 73: 1-13.
