This is an example file on how GRRO and GRRO_LS [1] could be used. 

[1] J. Zhang, Y. Lin, M. Jiang, S. Li, Y. Tang, K. C. Tan. Multi-label feature selection via global relevance and redundancy optimization. In Proceedings of the 29th International Joint Conference on Artificial Intelligence (IJCAI’20), Yokohama, Japan, 2020.

Please feel free to contact me (zhangjia_gl@163.com), if you have any problem about this program.
