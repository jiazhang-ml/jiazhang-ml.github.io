This is an example file on how the MDFS [1] program could be used.

[1] J. Zhang, Z. Luo, C. Li, C. Zhou, S. Li, Manifold regularized discriminative feature selection for multi-label learning, Pattern Recognition, 2019, 95: 136-150.

Please run demo.m directly.

Please feel free to contact me (zhangjia_gl@163.com), if you have any problem about this program.
