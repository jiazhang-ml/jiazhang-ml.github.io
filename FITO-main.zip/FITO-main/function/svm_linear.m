    function [ Pre_Labels, Outputs ] = svm_linear( cv_train_data, cv_test_data, cv_train_target, cv_test_target )

    % SVM with linear kernel
    cv_train_target=cv_train_target';cv_test_target=cv_test_target';
    [num_class,num_test]=size(cv_test_target);
    Pre_Labels=[]; Outputs=[];
    for i=1:num_class
        training_instance_matrix=cv_train_data; 
        training_label_vector=cv_train_target(i,:)';
        Models{i,1}=svmtrain(training_label_vector,training_instance_matrix,'-t 0 -b 1');
    end
        
    for i=1:num_class
        testing_instance_matrix=cv_test_data; 
        testing_label_vector=cv_test_target(i,:)';
        [predicted_label,accuracy,prob_estimates]=svmpredict(testing_label_vector,testing_instance_matrix,Models{i,1},'-b 1');
        if(isempty(predicted_label))
            predicted_label=cv_train_target(i,1)*ones(num_test,1);
            if(cv_train_target(i,1)==1)
                Prob_pos=ones(num_test,1);
            else
                Prob_pos=zeros(num_test,1);
            end
            Outputs=[Outputs;Prob_pos']; 
            Pre_Labels=[Pre_Labels;predicted_label'];
        else
            pos_index=find(Models{i,1}.Label==1); 
            Prob_pos=prob_estimates(:,pos_index);
            Outputs=[Outputs;Prob_pos']; 
            Pre_Labels=[Pre_Labels;predicted_label'];
        end
    end
    Outputs = Outputs';
    Pre_Labels = Pre_Labels';

