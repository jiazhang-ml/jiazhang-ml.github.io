clear;clc; addpath(genpath('.\'))

% DEAP
subject = 32;
trial = 40;

load('deap_original.mat')

para.alpha=0.01;para.beta=100;

features=features_normalized;

for j=1:50
    split_data;

    numB=2; [train_data train_target]=trans(X_train,Y_train',numB); % ÀëÉ¢»¯

    [~,num_feature] = size(train_data);

    FF=zeros(num_feature,num_feature);
    FL=zeros(num_feature,1);

    % Note that the code of Fuzzy Mutual Information used in this paper is provided by other institution. As an alternative, we use cvx toolbox to obtain an approximate result. 
    for i=1:num_feature
		% The relevance betwwen feature and label
		FL(i,1)=mi(train_data(:,i),Y_train);
    end

    for i=1:num_feature
        for h=1:num_feature
            % The redundancy betwwen features
            FF(i,h)=mi(train_data(:,i),train_data(:,h));
        end
    end

    for i=1:num_feature
        FF(i,i)=1;
    end

    W = sparse_representation(X_train);
    Z(:,j)=(eye(num_feature)+para.alpha*FF+para.beta*(eye(num_feature)-W)'*(eye(num_feature)-W))\FL;
    [dumb feature_idx(:,j)] = sort(sum(Z,2),'descend');
    
    t=50;
    for i = 1:t
        fprintf('Running the program with the selected features - %d/%d \n',i,t);
        f=feature_idx(1:i);
        Model=svmtrain(Y_train,X_train(:,f),'-t 0 -b 1');
        [predicted_label,accuracy,prob_estimates]=svmpredict(Y_test,X_test(:,f),Model);      
        ACC_PRO(j,i)=acc(predicted_label,Y_test);
    end
    ENT_PRO(:,j)=R_Entropy([X_train(:,feature_idx(1:50)); X_test(:,feature_idx(1:50))], [Y_train; Y_test]);
end
save('PRO_deap_original','Z','feature_idx','ACC_PRO','ENT_PRO');
