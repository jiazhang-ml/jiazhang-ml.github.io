This is an example file on how the FITO [1] program could be used.

[1] J. Zhang, S. Liu, H. Wu, Z. Zhang, J. Long. EEG feature selection in emotion recognition using a fuzzy information-theoretic based optimization approach. IEEE Transactions on Fuzzy Systems, 2025.

Please feel free to contact me (jiazhang@jnu.edu.cn), if you have any problem about this program.
