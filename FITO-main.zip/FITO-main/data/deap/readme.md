# DEAP
https://www.eecs.qmul.ac.uk/mmv/datasets/deap/readme.html

Features： 1280 x 1260 \
Labels： 1280 x 1  (arousal >= 0.5 then 1 else 0)

## Experiments:

1. EEG signals were collected with the 32-channel.
2. The participant ratings, physiological recordings and face video of an experiment where 32 volunteers watched a subset of 40 of the above music videos.


## Data Preprocessing:

1. The data was downsampled to 128Hz.
2. A bandpass frequency filter from 4.0-45.0Hz was applied.
3. The data was averaged to the common reference.
4. Independent component analysis (ICA) was then implemented to remove physiological artifacts.
5. The data was normalized from 0 to 1.
6. To examine the effectiveness of the different feature selection methods, 70% of the samples and the remaining 30% of the samples were randomly chosen as a training set and a test set, respectively. 
And all the samples of one subject were selected either as training set or test set to evaluate the generalization abilities of all the feature selection methods. 
In other words, the samples of one subject will not exist in the training set and test set at the same time.

## Data Summary
There is a total of 40 trials for each experiment.
The EEG channels were reordered so that they all follow the Geneva order as above.
The data was segmented into 60 second trials and a 3-second pre-trial baseline removed.
The trials were reordered from presentation order to video (Experiment_id) order.


