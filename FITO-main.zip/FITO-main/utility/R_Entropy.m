function ENT =R_Entropy(X_train,Y_train)
%% ����Representation Entropy

a=[X_train Y_train];
[m,n]=size(a);
entro=zeros(n-1,1);

for i=1:1:n-1
    data=a(:,1:i);
    c=cov(data);
    e=eig(c);
    se=sum(e);
    e=e/se;
    e=e.*log(e); 
    entro(i,1)=-sum(e)/i;
end

ENT=entro;