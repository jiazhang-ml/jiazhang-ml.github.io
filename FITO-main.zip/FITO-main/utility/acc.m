function A=acc(X,Y)
n=size(X,1);
t=0;
for i=1:n
    if X(i,1)==Y(i,1)
        t=t+1;
    else
        t=t;
    end
end
A=t/n;