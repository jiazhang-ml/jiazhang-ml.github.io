#### This is an example file on how the MSWL program could be used.

#### Please feel free to contact me (zhangjia_gl@163.com), if you have any problem about this program.
