This is an example file on how the GLFS [1] program could be used.

[1] J. Zhang, H. Wu, M. Jiang, J. Liu, S. Li, Y. Tang, J. Long. Group-preserving label-specific feature selection for multi-label learning, Expert Systems with Applications, 2022.

Please feel free to contact me (jiazhang@jnu.edu.cn), if you have any problem about this program.
